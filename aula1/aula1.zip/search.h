#ifndef SEARCH_H
#define SEARCH_H

int bin_search(int array[], int array_size, int key);
int seq_search(int array[], int array_size, int key);

#endif
